/**
 * Created by Administrator on 2017/5/29 0029.
 */
	$(document).ready(function(){
		King_Chance_Layer_Probability();
		});
